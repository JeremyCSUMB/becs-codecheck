#Replace the . . . below with an expression x = Floor division of two numbers to produce output 33
##HIDE
x = 100//3
##EDIT . . .
print(x)