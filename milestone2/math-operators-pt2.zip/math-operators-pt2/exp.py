#Replace the . . . below with an expression x = Exponent operator to get result 64
##HIDE
x = 2 ** 6
##EDIT . . .
print(x)