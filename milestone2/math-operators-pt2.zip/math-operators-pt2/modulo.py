#Replace the . . . below with an expression x = Modulo operation between two numbers to get the result 1
##HIDE
x = 21 % 10
##EDIT . . .
print(x)