##IGNORECASE false
#Replace the . . . below with a print statement 
#to print title with all lowercase 
title = "Bridge Experience for Computer Science"
##HIDE
print(title.lower())
##EDIT . . .
