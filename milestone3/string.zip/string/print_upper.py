##IGNORECASE false
#Replace the . . . below with a print statement 
#to print title with all uppercase 
title = "Bridge Experience for Computer Science"
##HIDE
print(title.upper())
##EDIT . . .
