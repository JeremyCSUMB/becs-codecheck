##IGNORECASE false
#Replace the . . . below with a print statement 
#to print title with the first letter each word in uppercase
title = "bridge experience for computer science"
##HIDE
print(title.title())
##EDIT . . .
