#Replace the . . . below with an expression x = Addition of two numbers with an output value of 23
##HIDE
x = 10 + 13
##EDIT . . .
print(x)