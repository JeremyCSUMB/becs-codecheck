#Replace the . . . below with an expression x = Difference of two numbers with an output value of 30
##HIDE
x = 50 - 20
##EDIT . . .
print(x)