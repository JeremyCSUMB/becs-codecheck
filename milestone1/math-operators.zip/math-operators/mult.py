#Replace the . . . below with an expression x = Factor of two numbers with output value of 120
##HIDE
x = 10 * 12
##EDIT . . .
print(x)