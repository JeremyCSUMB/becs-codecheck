#Replace the . . . below with an expression x = Quotient of two numbers with output value of 3.33333...
##HIDE
x = 10 / 3
##EDIT . . .
print(x)