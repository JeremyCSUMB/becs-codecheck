##IGNORECASE false
##IGNORESPACE false
#Replace the . . . to complete the following code
#It should print the number of hours worked given
# Weekly wage (weekly_wage)
# hourly rate (hourly_rate)
# Output should be formatted as follows:
# "Number of hours worked = "calculated number of hours
weekly_wage = 360
hourly_rate = 15.0
##HIDE
num_of_hours = weekly_wage / hourly_rate
print ("Number of hours worked = %s" %num_of_hours)
##EDIT . . .
