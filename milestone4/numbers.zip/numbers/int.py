#Replace the . . . below to initialize a variable i
#such that the value printed is 42
##HIDE
i = 42
##EDIT . . .
print (i)
