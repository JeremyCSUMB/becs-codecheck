#Replace the . . . below to initialize a variable x
#such that the value printed is 3.14
##HIDE
x = 3.14
##EDIT . . .
print (x)
