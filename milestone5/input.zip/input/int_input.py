##IGNORECASE false
##IGNORESPACE false
#Replace the . . . to complete the following code
#It should print the hourly wage for the given 
# number of hours (num_of_hours) which is taken as input
# hourly rate (hourly_rate)
# Output should be formatted as follows:
# "Weekly wage = "calculated wage
num_of_hours = int(input())
hourly_rate = 15.0
##HIDE
weekly_wage = num_of_hours * hourly_rate
print ("Weekly wage = %s" %weekly_wage)
##EDIT . . .
