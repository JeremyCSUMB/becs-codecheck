##IGNORECASE false
##IGNORESPACE false
#Replace the . . . with Python code
#That will print
#"What is your name? "
#Take name as input and print "Hello " input name
##HIDE
print("Hello "+ input("What is your name? "))
##EDIT . . .